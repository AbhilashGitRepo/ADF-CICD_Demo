# adf-cicd
A demo repository for my ADF Dev Factory
